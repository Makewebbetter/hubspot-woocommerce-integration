<?php 

/**
 * All HubSpot needed general settings.
 *
 * Template for showing/managing all the HubSpot general settings
 *
 * @since 1.0.0 
 */

global $hubwoo;

$GLOBALS['hide_save_button']  = true;

?>
<div class="hubwoo-overview-wrapper">
    <div class="hubwoo-overview-header hubwoo-common-header hubwoo-notice-header">
        <h2><?php _e("2 minutes setup guide", "hubwoo") ?></h2>
        <div class="hubwoo-header-content hubwoo-header-content">
            <span class="dashicons dashicons-media-text"></span>
            <?php _e( "This free plugin will sync registered users data after completing the setup with limited fields. For unlimited access to users data sync", "hubwoo" )?>
            <a href="https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG" class="hubwoo-notice-header__link"><?php _e( "GO PRO NOW", "hubwoo" ) ?></a>
        </div>
    </div>
    <div class="hubwoo-overview-body">
    	<div class="hubwoo-overview-container">
            <table class="hubwoo-compare">
                <thead>
                    <tr>
                        <th></th>
                        <th class="hubwoo-compare__hy"><?php _e( "Pro Version", "hubwoo" ) ?></th>
                        <th class="hubwoo-compare__ny"><?php _e( "ORG Version", "hubwoo" ) ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th><?php _e( "Guest Orders Sync (as contacts)", "hubwoo" ) ?></td>
                        <td class="hubwoo-compare__y">✓</td>
                        <td class="hubwoo-compare__n">✘</td>
                    </tr>
                    <tr>
                        <th><?php _e( "Full Purchase History", "hubwoo" ) ?></td>
                        <td class="hubwoo-compare__y">✓</td>
                        <td class="hubwoo-compare__n">✘</td>
                    </tr>
                    <tr>
                        <th><?php _e( "Active Lists and Enrollments", "hubwoo" )?></td>
                        <td class="hubwoo-compare__y">✓</td>
                        <td class="hubwoo-compare__n">✘</td>
                    </tr>
                    <tr>
                        <th><?php _e( "Workflows and Enrollments", "hubwoo" ) ?></td>
                        <td class="hubwoo-compare__y">✓</td>
                        <td class="hubwoo-compare__n">✘</td>
                    </tr>
                </tbody>
                <tfoot>
                    <tr>
                        <td></td>
                        <td colspan="2">
                            <a href="https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG" class="hubwoo__tbtn">
                                <?php _e( "Go Pro Now", "hubwoo" ) ?>
                            </a>
                        </td>
                    </tr>
                </tfoot>
            </table>
            <?php if( !self::hubwoo_get_started() ) { ?>
                    <a class="hubwoo__btn hubwoo-overview-get-started" href="javascript:void(0)"><?php _e("Get Started With Free", "hubwoo")?></a>
                <?php
                }
            ?>
        </div>
    </div>
</div>