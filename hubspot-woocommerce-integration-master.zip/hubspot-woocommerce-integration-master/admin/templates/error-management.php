<?php 

global $hubwoo; 

$success_calls = get_option( "hubwoo-free-success-api-calls", 0 );
$failed_calls = get_option( "hubwoo-free-error-api-calls", 0 );
$error_class= '';
?>

<div class="hubwoo-connect-form-header hubwoo-common-header">
	<h2><?php _e("Error Tracking","hubwoo") ?></h2>
	<div class="hubwoo-header-content">
	  <?php _e( "Track your HubSpot API usage and count on daily basis. In case, failed API calls keeps on increasing then please connect with us using our Chat Now option.", "hubwoo")?>
	</div>
</div>
<?php if( get_option( "hubwoo_alert_param_set" ) ) {
		$error_class = 'hubwoo_extn_no';
	}
	else {
		$error_class = 'hubwoo_extn_yes';
	}
	?>
<div class="hubwoo-extn-status <?php echo $error_class;?>">
	<div class="hubwoo-notice-sym">
		<span></span>
	</div>
	<p><?php _e("Extension Current Status", "hubwoo") ?></p>
</div>

<div class="hubwoo-error-info">
	<div class="hubwoo-error">
		<p class="hubwoo-total-calls">
			<?php _e( "Total API Calls","hubwoo") ?>
		</p>
		<p class="hubwoo-error-text">
			<?php echo __( "Count: ", "hubwoo") . ( $success_calls + $failed_calls );?>
		</p>
	</div>
	<div class="hubwoo-error">
		<p class="hubwoo-success-calls">
			<?php _e( "Success API Calls","hubwoo") ?>
		</p>
		<p class="hubwoo-error-text">
			<?php echo __( "Count: ", "hubwoo" ) . $success_calls; ?>
		</p>
	</div>
	<div class="hubwoo-error">
		<p class="hubwoo-failed-calls">
			<?php _e( "Failed API Calls","hubwoo") ?>
		</p>
		<p class="hubwoo-error-text">
			<?php echo __( "Count: ", "hubwoo" ) . $failed_calls; ?>
		</p>
	</div>
</div>
<div>
	<h4><?php _e( "List of Invalid Emails for HubSpot API", "hubwoo" ) ?></h4>
	<?php
		$invalidEmails = get_option( "hubwoo_invalid_emails", array() );
		if ( !empty( $invalidEmails ) ) {
			?>
			<table class="hubwoo-emails-table">
				<tr>
					<th><?php _e( "Email", "hubwoo" ) ?></th>
				</tr>
				<?php
				foreach ( $invalidEmails as $single_email ) {
					?>
						<tr>
							<td><?php echo $single_email ?></td>
						</tr>
					<?php
				}
				?>
			</table>
			<?php
		}
		else {
			?>
				<p><?php _e( "No emails yet", "hubwoo" ) ?></p>
			<?php
		}
	?>
</div>