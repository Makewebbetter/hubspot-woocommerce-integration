<div class="hubwoo-fields-header hubwoo-common-header">
	<h2><?php _e("Marketing Automation and Segmentation","hubwoo") ?></h2>
  <div class="hubwoo-header-content">
    <?php _e( "Get pre-defined Active lists and automated workflows for your HubSpot Account and start automating your daily basis tasks smoothly.", "hubwoo" ) ?>
  </div>
</div>
<center><img style="width: 50%" src="<?php echo HUBWOO_URL . 'admin/images/lists-workflows.gif' ?>"></center>
<div style="text-align: center;" class="hubwoo_pro_support_dev">
  <button onclick="location.href='https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG'" class="hubwoo-go-pro-now hubwoo__btn"><?php _e("Get this Feature Now", "hubwoo")?></button> 
</div>