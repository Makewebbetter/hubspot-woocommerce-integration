<div class="hubwoo-fields-header hubwoo-common-header">
	<h2><?php _e("Track your sales with HubSpot Deal Per Order Add-on","hubwoo") ?></h2>
  <div class="hubwoo-header-content">
    <?php _e("It allows you to convert the individual potential sale of your store into HubSpot Deals with appropriate deal stage, amount and closing date.", "hubwoo")?>
  </div>
</div>

<center><img data-toggle="modal" data-target="#myModal" style="width:80%;" src="<?php echo HUBWOO_URL . 'admin/images/hubspot-deals.png' ?>"></center>

<div style="text-align: center;" class="hubwoo_pro_support_dev">
  <button onclick="location.href='https://makewebbetter.com/product/hubspot-woocommerce-deal-per-order/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG'" class="hubwoo-go-pro-now hubwoo__btn"><?php _e("Get this Feature Now", "hubwoo")?></button>
</div>