=== HubSpot WooCommerce Integration ===
Contributors: MakeWebBetter
Donate link: https://makewebbetter.com/
Tags: hubspot premier integration, hubspot,hubspot woocommerce integration,marketing automation, certified hubspot integraton provider
Tested up to: 5.2.2
Requires at least: 3.4
Stable tag: 3.0.0
Requires PHP: 5.6
WC Requires at least: 3.0.0
WC Tested up to: 3.6.4
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

**Automate your Marketing to Sell More. Choose Intelligent eCommerce Automation by connecting your WooCommerce store with HubSpot via Certified Premier Integration Partner of HubSpot.**

**HubSpot WooCommerce Integration** helps you to send your WooCommerce Data Viz. Customers, Orders, Coupons, abandoned cart, and other processed information to HubSpot automatically. Personalize your customer experience, and get the best of HubSpot CRM (that is absolutely FREE) for your WooCommerce store.

Based on the HubSpot Plan, you choose for your Sales and Marketing, this extension helps you to automate and personalize your email marketing campaigns, segment your customers with HubSpot Smart Lists, create deals for every order, perform revenue forecasting and much more.

This extension automatically creates best-practiced groups, contact properties, and build smart workflows based on your customer’s purchase history, post-purchase follow-ups abandoned cart emails, and win-back campaigns all at one place, that saves time and provides a customized **HubSpot for WooCommerce.**


[youtube https://www.youtube.com/watch?v=ALUXAyY6EYw#rel=0]

**Check out our blog for the features that you wish to have in your HubSpot Plan.**

== MAIN FEATURES ==

* Best Practiced Groups and Contact Properties
* Sellers can enlist different groups based on the recent purchases of customers (added in 1.1.0)
* Sellers can assign various rules to different Customer Groups 
* Provides real-time user activity syncing. 
* Real-time order details syncing 
* RFM rating for customers(added in 1.1.2)
* The HubSpot WooCommerce Integration plugin is highly optimized and super flexible to meet your business requirements
* Optimized backend scheduler to sync real-time data update to HubSpot without affecting server performance 
* Sellers can enable logging for each and every API requests to HubSpot
* OAuth 2.0 for secure authentication the plugin with HubSpot


> Note: The features listed below are available with the Premium version of HubSpot WooCommerce Integration. This implies that you need HubSpot WooCommerce Integration – PRO to leverage all these exclusive features. You can easily get  [the premium version here](https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG)


== PRO FEATURES ==

* Data Syncing based on Purchase Historical data sync
* 70+ Contact Properties Sync
* 20+ HubSpot Smart Lists
* 10+ Ready to Use HubSpot Workflows
* RFM Segmentation
* ROI Tracking
* Provides real-time user activity syncing for the guest as well as registered users.
* Real-time order details syncing
* Full product purchase history of store customers
* Full purchase history of SKUs and categories
* Guest Customer Data Sync
* Compatible with **WooCommerce Subscriptions plugin** and pushes subscription data over HubSpot
* Shopping cart details
* Sellers can enlist different groups based on the recent purchases of customers
* Highly optimized and super flexible 
* The user can get an easy way to manage all products listings, customer contacts & order pipelines via singular dashboard. He can also manage  7 default reports like this. 




**Know the Differences**

What is the difference between [**Free & PRO**](https://in.pinterest.com/pin/677299231439570686/#utm_source=hubspot-org&utm_medium=org) Version of Integration ? 


If you’re unsure what to choose, try the premium version in [$1](https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/#mwb_trail_product/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG) and if you don't like the [HubSpot WooCommerce Integration PRO](https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG) features, you can rollback to free at any time. 


Start and review your process, with our [Step by step setup guide on HubSpot](https://makewebbetter.com/blog/how-to-connect-your-woocommerce-store-with-hubspot/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG) or schedule a [1-on-1](https://makewebbetter.com/blog/how-to-connect-your-woocommerce-store-with-hubspot/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG) setup guide with our expert.


= Pick up your suitable extension according to your HubSpot CRM package and get access to more features =

* [HubSpot WooCommerce Integration FREE](https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG#pricing)- for Free HubSpot CRM users
* [HubSpot WooCommerce Integration STARTER](https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG#pricing)- for Starter/Basic HubSpot CRM users
* [HubSpot WooCommerce Integration PRO](https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG#pricing)- for Professional/Enterprise HubSpot CRM users

**Add-Ons for scaling features**

* [HubSpot Abandoned Cart Recovery](https://makewebbetter.com/product/hubspot-abandoned-cart-recovery/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG)
* [HubSpot Field to Field Sync](https://makewebbetter.com/product/hubspot-field-to-field-sync/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG)
* [HubSpot Dynamic Coupon Code Generation](https://makewebbetter.com/product/hubspot-dynamic-coupon-code-generation/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG)
* [HubSpot Deal Per Order](https://makewebbetter.com/product/hubspot-woocommerce-deal-per-order/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG)
* [HubSpot Deals for WooCommerce Memberships](https://makewebbetter.com/product/hubspot-deals-for-woocommerce-memberships/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG)
* [Premium Trial](https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG)



= INSTALLATION PROCESS AND PLUGIN WALKTHROUGH =

* Plugin walk-through – [click here](https://wordpress.org/plugins/hubwoo-integration/#screenshots)



= MINIMUM REQUIREMENTS  =


* WordPress 4.0 or greater
* WooCommerce 3.0.0 or greater
* PHP version 5.6 or greater
* MySQL version 5.0 or greater

= PLUGIN DOCUMENTATION =

* **Documentation** - [documentation](https://docs.makewebbetter.com/hubspot-woocommerce-integration/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG)

= ANY SUGGESTIONS? =

We value your suggestions. Please let us know if there is anything you want to share with us or guide us about. 

**SUPPORT**

In case of any query please contact us [here](https://makewebbetter.freshdesk.com/support/tickets/new) or send us email at [support@makewebbetter.com](mailto:support@makewebbetter.com)

**Follow Us**

* **Our Official Website** - [https://makewebbetter.com/](https://makewebbetter.com/?utm_source=MWB-huspot-org&utm_medium=MWB-ORG&utm_campaign=ORG) 
* **Our Facebook Page** - [https://www.facebook.com/makewebbetter](https://www.facebook.com/makewebbetter)
* **Our Twitter Account** - [https://twitter.com/makewebbetter](https://twitter.com/makewebbetter)
* **Our LinkedIn Account** - [https://www.linkedin.com/company/makewebbetter](https://www.linkedin.com/company/makewebbetter)

== Installation ==

= Automatic installation =

In the search field type “HubSpot WooCommerce Integration” and click Search Plugins. Once you’ve found our ‘HubSpot WooCommerce Integration’ you can view details about it such as the point release, rating and description. Most importantly of course, you can install it by simply clicking “Install Now”.


= Manual installation =

The manual installation method involves downloading the plugin and uploading it to your webserver via your favourite FTP application. The WordPress codex contains [instructions on how to do this here](http://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

== Frequently Asked Questions ==

= Installation Instructions =

1. Go to the HubSpot WooCommerce Settings page and Enable the integration. 
2. Enable the logging of each API request. 
3. Save the settings.
4. Next, click on the authorize button on the setting page. 
5. After successful authentication of OAuth 2.0, click on Run Setup.
6. And you are done! The groups and their associated properties are uploaded to HubSpot along with a cron.
7. Any updated information is pushed to HubSpot through the cron.

= Details are not syncing instantly =

We provide the updating in every 5 minutes. However, HubSpot takes some time to reflect the properties. There are the few points you can crosscheck:

- Please update the integration with the latest version.
- Check API logs.
- Please contact us, if still facing issues.

=  I just installed your plugin and am wondering if there is a sync of HubSpot contact details to the WooCommerce user database since this is the missing link I search for most. Is there anything else that I need to set up to get this working? =

There is no extra setup needed as the updated information is synced with Hubspot within 5 minutes. 

The plugin only updates the field data that are created. If you feel some extra fields or other data is needed, please feel free to contact us. 

= Does this plugin have a premium version too? =

Yes, you can get the premium version of HubSpot WooCommerce Integration by clicking [here](https://makewebbetter.com/product/hubspot-woocommerce-integration-pro/?utm_source=MWB-hubspot-org&utm_medium=MWB-ORG&utm_campaign=ORG) 

== Screenshots ==
1. Plugin Walkthrough
2. HubSpot Workflow Example
3. Setup
4. Authorize
5. Access
6. Connected Status
7. Create Fields
8. Fields Created
9. General Settings
10. Error Tracking
11. Customer Information Group
12. Last Order Details
13. RFM information 

== Changelog ==

= 3.0.1 =
* Ecommerce Scopes added

= 2.0.0 =
* New layout and change of HubSpot multi-checkboxes field to multi-line text

= 1.1.5 =
* Compatibility with GDPR privacy policy

= 1.1.4 =
* Bug fixes.

= 1.1.3 =
* Added admin notice for showing warning on getting 40X error in api calls.

= 1.1.2 =
* Added new properties for RFM ratings and add-ons compatibility.

= 1.1.1 =
* Fix details schedule syncing issue.

= 1.1.0 =
* Added RFM Information Group with their associated properties

= 1.0.0 =
* Initial release.

== Upgrade Notice ==

= 3.0.1 =
* Ecommerce Scopes added











